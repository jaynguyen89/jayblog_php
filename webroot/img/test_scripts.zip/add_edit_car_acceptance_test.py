import unittest
from selenium import webdriver
from random import randint
from selenium.webdriver.common.keys import Keys

browser = webdriver.Chrome("C:/Program Files/chromedriver.exe")
browser.maximize_window()
browser.get("http://localhost/CarShareApp/")


class AddEditCarTest(unittest.TestCase):
    def test_a_addcar_step1(self):
        self.login()

        next_btn = browser.find_element_by_id("nextstep")
        make_checkbox = browser.find_element_by_id("selectmake")
        make_field = browser.find_element_by_id("maketext")

        make_checkbox.click()
        make_field.clear()
        make_field.send_keys("Mercedes")

        model_field = browser.find_element_by_id("modeltext")
        model_field.clear()
        model_field.send_keys("E200K Elegant")

        year_field = browser.find_element_by_id("year")
        year_field.clear()
        year_field.send_keys("2012")

        color_radio = browser.find_element_by_css_selector("input[type='radio'][value='White']")
        color_radio.click()

        trans_radio = browser.find_element_by_css_selector("input[type='radio'][value='Auto']")
        trans_radio.click()

        type_drop = browser.find_element_by_id("type")
        type_options = type_drop.find_element_by_tag_name("option")
        type_options[randint(0, len(type_options) - 1)].click()

        fuel_drop = browser.find_element_by_id("fueltype")
        fuel_options = fuel_drop.find_element_by_tag_name("option")
        fuel_options[randint(0, len(fuel_options) - 1)].click()

        odo_field = browser.find_element_by_id("odometer")
        odo_field.clear()
        odo_field.send_keys("213546")

        length_field = browser.find_element_by_id("length")
        width_field = browser.find_element_by_id("width")
        height_field = browser.find_element_by_id("height")

        length_field.clear()
        length_field.send_keys("4321")
        width_field.clear()
        width_field.send_keys("3421")
        height_field.clear()
        height_field.send_keys("1432")

        self.assertEquals(next_btn.is_enabled(), True)
        next_btn.click()
        assert "http://localhost/CarShareApp/cars/add-second" in browser.current_url

    def test_b_addcar_step2(self):
        next_btn = browser.find_element_by_id("nextstep")

        dropdowns = []
        drive_drop = browser.find_element_by_id("drivetype")
        engine_drop = browser.find_element_by_id("enginetype")
        induct_drop = browser.find_element_by_id("induction")
        gear_drop = browser.find_element_by_id("geartype")

        dropdowns[0] = drive_drop
        dropdowns[1] = engine_drop
        dropdowns[2] = induct_drop
        dropdowns[3] = gear_drop

        for dropdown in dropdowns:
            drop_options = dropdown.find_element_by_tag_name("option")
            drop_options[0, len(drop_options) - 1].click()

        engine_field = browser.find_element_by_id("enginesize")
        cylinder_field = browser.find_element_by_id("cylinder")
        watt_field = browser.find_element_by_id("watt")
        round_field = browser.find_element_by_id("round")
        gear_field = browser.find_element_by_id("gear")
        fuel_field = browser.find_element_by_id("fuelcap")
        ave_field = browser.find_element_by_id("average")
        rur_field = browser.find_element_by_id("rural")
        urb_field = browser.find_element_by_id("urbane")

        engine_field.send_keys("3212")
        cylinder_field.send_keys("4")
        watt_field.send_keys("400")
        round_field.send_keys("5000")
        gear_field.send_keys("6")
        fuel_field.send_keys("75")
        ave_field.send_keys("7.6")
        rur_field.send_keys("5.1")
        urb_field.send_keys("10.1")

        self.assertEquals(next_btn.is_enabled(), True)
        next_btn.click()
        assert "http://localhost/CarShareApp/cars/add-third" in browser.current_url

    def test_c_addcar_step3(self):
        next_btn = browser.find_element_by_id("nextstep")

        audio_checkbox = browser.find_element_by_id("selectaudio")
        audio_field = browser.find_element_by_id("audiotext")

        audio_inputs = ["Super bass", "Central subwoofer", "Bluetooth", "USB", "Touch display", "FM Radio", "Phone call",
                        "CD/DVD Player", "Sound Adjustment", "Android Auto", "Backlight Dim/Night modes", "Hearing aids"]

        audio_checkbox.click()
        for input in audio_inputs:
            audio_field.clear()
            audio_field.send_keys(input)
            browser.find_element_by_id("selectconv").click()

        others_checkbox = browser.find_element_by_id("selectothers")
        others_field = browser.find_element_by_id("othertext")

        other_inputs = ["Test other 1", "Test other 2", "Test other 3", "Test other 4", "Test other 5", "Test other 6",
                        "Test other 7", "Test other 8", "Test other 9", "Test other 10", "Test other 11", "Test other 12"]

        others_checkbox.click()
        for input in other_inputs:
            others_field.clear()
            others_field.send_keys(input)
            browser.find_element_by_id("selectconv").click()

        next_btn.click()
        assert "http://localhost/CarShareApp/cars/add-fourth" in browser.current_url

    def test_d_addcar_step4(self):
        next_btn = browser.find_element_by_id("nextstep")

        long_field = browser.find_element_by_id("countlong")
        long_field.send_keys("Test")
        long_field.clear()

        self.assertEquals(next_btn.is_enabled(), True)
        next_btn.click()
        assert "http://localhost/CarShareApp/cars/add-last" in browser.current_url

    def test_e_addcar_step5(self):
        submit_btn = browser.find_element_by_id("publish")
        self.assertEquals(submit_btn.is_enabled(), False)

        ddprice_field = browser.find_element_by_id("ddprice")
        kmprice_field = browser.find_element_by_id("kmprice")
        park_field = browser.find_element_by_id("parking")
        slotfield = browser.find_element_by_id("slot")

        ddprice_field.clear()
        ddprice_field.send_keys("255.99")

        kmprice_field.clear()
        kmprice_field.send_keys("65.50")

        park_field.clear()
        park_field.send_keys("211 Ferrars St, South Melbourne, VIC 3205")

        slotfield.clear()
        slotfield.send_keys("TS203C")

        self.assertEquals(submit_btn.is_enabled(), True)
        submit_btn.click()
        assert "The car has been added into your business. You can find it here." in browser.page_source
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars")

    @staticmethod
    def login():
        login_btn = browser.find_element_by_link_text("LOG IN")
        login_btn.click()

        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("makarov")

        password_input.clear()
        password_input.send_keys("Makarov!pw")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

if __name__ == '__main__':
    runTests = AddEditCarTest()

    runTests.test_a_addcar_step1()
    runTests.test_b_addcar_step2()
    runTests.test_c_addcar_step3()
    runTests.test_d_addcar_step4()
    runTests.test_e_addcar_step5()
