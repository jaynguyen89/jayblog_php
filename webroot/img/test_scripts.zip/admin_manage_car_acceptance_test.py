import unittest
from selenium import webdriver
from random import randint

browser = webdriver.Chrome("C:/Program Files/chromedriver.exe")
browser.maximize_window()
browser.get("http://localhost/CarShareApp/")

# Test admin search field
# Test admin suspending cars, reviving cars, updating car


class AdminManageCar(unittest.TestCase):
    items = []
    suspend_btns = []

    def test_a_search_field(self):
        self.login()
        car_tab = browser.find_element_by_link_text("Cars")
        car_tab.click()

        search_btn = browser.find_element_by_id("search_submit")
        id_field = browser.find_element_by_id("carid")
        keyword_field = browser.find_element_by_id("carword")
        self.assertEquals(search_btn.is_enabled(), False)

        test_inputs = ["    ", "test", "123 ", "test!", "!@#$", "0000", " ", "0"]

        for input in test_inputs:
            id_field.clear()
            id_field.send_keys(input)
            keyword_field.click()

            assert "Car ID only contains digits." in browser.page_source
            self.assertEquals(search_btn.is_enabled(), False)

        id_field.clear()
        assert "Car ID only contains digits." not in browser.page_source
        self.assertEquals(search_btn.is_enabled(), False)

        id_field.send_keys("10")
        keyword_field.clear()
        keyword_field.send_keys("test")
        id_field.click()

        assert "Please only use 1 search type at a time." in browser.page_source
        self.assertEquals(search_btn.is_enabled(), False)

        keyword_field.clear()
        id_field.click()
        assert "Please only use 1 search type at a time." not in browser.page_source
        self.assertEquals(search_btn.is_enabled(), True)

        search_btn.click()
        assert "The search was completed with 1 result. This is the car by the searched ID." in browser.page_source
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars/view?carid=10&from=adminview")

        car_tab = browser.find_element_by_link_text("Cars")
        car_tab.click()

        keyword_field = browser.find_element_by_id("carword")
        keyword_field.send_keys("Toyota")

        search_btn = browser.find_element_by_id("search_submit")
        search_btn.click()

        assert "The search was completed with" in browser.page_source
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/search")

        keyword_field = browser.find_element_by_id("carword")
        keyword_field.send_keys("Something")

        search_btn = browser.find_element_by_id("search_submit")
        search_btn.click()

        assert "The search was not completed. No records found with the searched ID/Keyword." in browser.page_source
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/search")

        car_tab = browser.find_element_by_link_text("Cars")
        car_tab.click()

    def test_b_suspend_revive(self):
        self.suspend_btns = browser.find_elements_by_link_text("SUSPEND")
        self.suspend_btns[randint(0, len(self.suspend_btns) - 1)].click()

        current_btns = browser.find_elements_by_link_text("SUSPEND")
        assert "The car has been unavailable for further business activities." in browser.page_source
        self.assertEquals(len(current_btns), len(self.suspend_btns) - 1)
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars")

        revive_tab = browser.find_element_by_link_text("Revive")
        revive_tab.click()

        self.items = browser.find_elements_by_link_text("REVIVE")
        selected_revive_btn = self.items[randint(0, len(self.items) - 1)]
        selected_revive_btn.click()

        current_items = browser.find_elements_by_link_text("REVIVE")
        self.assertEquals(len(current_items), len(self.items) - 1)
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars/revive")

    def test_c_update_car(self):
        update_btns = browser.find_elements_by_link_text("UPDATE INFO")
        selected_update_btn = update_btns[randint(0, len(update_btns) - 1)]

        selected_update_btn.click()

        drivetype_field = browser.find_element_by_id("drivetype")
        fuel_field = browser.find_element_by_id("fuelcap")
        type_field = browser.find_element_by_id("type")
        trans_field = browser.find_element_by_id("transmission")
        gear_field = browser.find_element_by_id("geartype")

        drivetype_field.send_keys("FWD")
        fuel_field.send_keys("90")
        type_field.send_keys("Sedan")
        trans_field.send_keys("2")
        gear_field.send_keys("Assisted")

        submit_btn = browser.find_element_by_id("submit")
        submit_btn.click()

        assert "The car has been saved." in browser.page_source
        self.assertEquals("http://localhost/CarShareApp/cars/revive", browser.page_source)

    @staticmethod
    def login():
        login_btn = browser.find_element_by_link_text("LOG IN")
        login_btn.click()

        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("makarov")

        password_input.clear()
        password_input.send_keys("Makarov!pw")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

if __name__ == '__main__':
    runTests = AdminManageCar()

    runTests.test_a_search_field()
    runTests.test_b_suspend_revive()
    runTests.test_c_update_car()
