import unittest
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException

browser = webdriver.Chrome("C:/Program Files/chromedriver.exe")
browser.maximize_window()
browser.get("http://localhost/CarShareApp/")


class LoginTest(unittest.TestCase):
    def test_a_login_button(self):
        login_btn_lookup = self.check_existence("LOG IN")
        self.assertEquals(login_btn_lookup, True)

        if login_btn_lookup:
            login_btn = browser.find_element_by_link_text("LOG IN")
            login_btn.click()

            self.assertEquals(browser.current_url, "http://localhost/CarShareApp/users/login")
        else:
            self.skipTest("Implementation glitch. No login button!")

    def test_b_login_space_username(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("   ")

        password_input.clear()
        password_input.send_keys("123456")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_c_login_space_password(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("PikacHu")

        password_input.clear()
        password_input.send_keys("   ")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_d_login_number1(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("32874872")

        password_input.clear()
        password_input.send_keys("123456")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_e_login_number2(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("0000000")

        password_input.clear()
        password_input.send_keys("123456")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_f_login_number3(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("-32874872")

        password_input.clear()
        password_input.send_keys("123456")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_g_login_special_chars1(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("P!ka6hu")

        password_input.clear()
        password_input.send_keys("123456")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_h_login_special_chars2(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("&$^*&(*$&#")

        password_input.clear()
        password_input.send_keys("123456")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_i_login_mix1(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys(";drop table users;")

        password_input.clear()
        password_input.send_keys("123456")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_j_login_mix2(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("u$ER_n!m3")

        password_input.clear()
        password_input.send_keys("123456")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_k_login_mix3(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("Pika__chu")

        password_input.clear()
        password_input.send_keys("123456")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Invalid username or password. Please try again." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, False)

    def test_l_login_successful(self):
        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("natsu")

        password_input.clear()
        password_input.send_keys("Natsu!pw")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        assert "Welcome! Natsu" in browser.page_source
        assert "Congrat! You have logged in successfully." in browser.page_source

        is_present = self.check_existence("LOGOUT")
        self.assertEqual(is_present, True)

    def test_m_logout(self):
        logout_btn = browser.find_element_by_link_text("LOGOUT")
        logout_btn.click()

        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/")

        is_present = self.check_existence("LOGOUT")
        self.assertEquals(is_present, False)

    @staticmethod
    def check_existence(title=""):
        try:
            browser.find_element_by_link_text(title)
        except NoSuchElementException:
            return False
        return True

    @staticmethod
    def refresh():
        browser.find_element_by_tag_name("body").send_keys(Keys.F5)


if __name__ == '__main__':
    runTests = LoginTest()

    runTests.test_a_login_button()
    runTests.refresh()
    runTests.test_b_login_space_username()
    runTests.refresh()
    runTests.test_c_login_space_password()
    runTests.refresh()
    runTests.test_d_login_number1()
    runTests.refresh()
    runTests.test_e_login_number2()
    runTests.refresh()
    runTests.test_f_login_number3()
    runTests.refresh()
    runTests.test_g_login_special_chars1()
    runTests.refresh()
    runTests.test_h_login_special_chars2()
    runTests.refresh()
    runTests.test_i_login_mix1()
    runTests.refresh()
    runTests.test_j_login_mix2()
    runTests.refresh()
    runTests.test_k_login_mix3()
    runTests.refresh()
    runTests.test_l_login_successful()
    runTests.refresh()
    runTests.test_m_logout()

    browser.stop_client()
    browser.close()
