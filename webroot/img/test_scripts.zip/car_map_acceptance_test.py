import unittest
from selenium import webdriver
from random import randint

browser = webdriver.Chrome("C:/Program Files/chromedriver.exe")
browser.maximize_window()
browser.get("http://localhost/CarShareApp/")


class CarMapTest(unittest.TestCase):
    google_map = browser.find_element_by_id("map")

    def test_a_markers(self):
        map_tab = browser.find_element_by_link_text("Map")
        map_tab.click()

        markers = self.google_map.find_elements_by_tag_name("div")
        assert len(markers) > 0
        duplicate = False

        titles = []
        for marker in markers:
            title = marker["title"]
            if title in titles:
                duplicate = True
                break

            titles.append(title)

        self.assertEquals(duplicate, False)

    def test_b_display_markers(self):
        display_div = browser.find_element_by_id("displaycars")
        content = display_div.find_element_by_css_selector("div[class='card']")

        self.assertIsNone(content)

        markers = self.google_map.find_elements_by_tag_name("div")
        selected_marker = markers[randint(0, len(markers) - 1)]
        selected_marker.click()

        display_div = browser.find_element_by_id("displaycars")
        content = display_div.find_element_by_css_selector("div[class='card']")

        self.assertIsNotNone(content)

    @staticmethod
    def login():
        login_btn = browser.find_element_by_link_text("LOG IN")
        login_btn.click()

        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("natsu")

        password_input.clear()
        password_input.send_keys("Natsu!pw")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

if __name__ == '__main__':
    runTests = CarMapTest()

    runTests.test_a_markers()

    exe_count = 10
    for count in range(0, exe_count):
        runTests.test_b_display_markers()

    runTests.login()
    map_tab = browser.find_element_by_link_text("Map")
    map_tab.click()

    runTests.test_a_markers()

    for count in range(0, exe_count):
        runTests.test_b_display_markers()