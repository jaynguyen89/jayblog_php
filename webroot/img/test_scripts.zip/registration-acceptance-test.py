import unittest
import time
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException

browser = webdriver.Chrome("C:/Program Files/chromedriver.exe")
browser.maximize_window()
browser.get("http://localhost/CarShareApp/")


class RegistrationTest(unittest.TestCase):
    def test_a_signup_button(self):
        signup_btn_lookup = self.check_existence("SIGN UP")
        self.assertEquals(signup_btn_lookup, True)

        if signup_btn_lookup:
            signup_btn = browser.find_element_by_link_text("SIGN UP")
            signup_btn.click()

            self.assertEquals(browser.current_url, "http://localhost/CarShareApp/users/add")
        else:
            self.skipTest("Implementation glitch. No signup button!")

    def test_b_password_error_message(self):
        pw_field = browser.find_element_by_id("password")
        pwMessage = browser.find_element_by_id("pwmessage")

        self.assertEquals(pwMessage.is_displayed(), False)

        pw_field.clear()
        pw_field.send_keys("shortpw")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require uppercase chars! Require special chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("verylongggpasswords")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require uppercase chars! Require special chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("short!")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require uppercase chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("verylongggpasswords!")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require uppercase chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("Shortpw")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require special chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("Shortpw")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require special chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("verylongggPasswords")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require special chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("verylongggPasswords")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require special chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("pwnoupper")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Require uppercase chars! Require special chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("pwno upper")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Require uppercase chars! Remove whitespace!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("sho rt")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require uppercase chars! Remove whitespace!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("very longggpassword")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Require uppercase chars! Remove whitespace!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("Sho rt")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Remove whitespace!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("very Longggpasswords")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16. Remove whitespace!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("VerylongPa$$words")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16.")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("Sho&t")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Length 8-16.")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("password!")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Require uppercase chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("Password")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Require special chars!")
        time.sleep(1)

        pw_field.clear()
        pw_field.send_keys("Pass word!")

        self.assertEquals(pwMessage.is_displayed(), True)

        message = pwMessage.text
        self.assertEquals(message, "Remove whitespace!")
        time.sleep(1)

    def test_c_valid_password(self):
        pw_field = browser.find_element_by_id("password")
        pwMessage = browser.find_element_by_id("pwmessage")
        submit_btn = browser.find_element_by_id("submit")

        self.assertEquals(pwMessage.is_displayed(), True)

        pw_field.clear()
        pw_field.send_keys("Password!")

        self.assertEquals(pwMessage.is_displayed(), False)
        self.assertEquals(submit_btn.is_enabled(), False)

    def test_d_confirm_password(self):
        pwConfirm_field = browser.find_element_by_id("confirm")
        pcMessage = browser.find_element_by_id("pcmessage")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Something")

        message = pcMessage.text
        self.assertEquals(message, "Password not matched. Re-type password!")
        self.assertEquals(submit_btn.is_enabled(), False)

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        self.assertEquals(pcMessage.is_displayed(), False)
        self.assertEquals(submit_btn.is_enabled(), True)

    def test_e_other_inputs(self):
        uname_field = browser.find_element_by_id("username")
        pw_field = browser.find_element_by_id("password")
        pwConfirm_field = browser.find_element_by_id("confirm")
        name_field = browser.find_element_by_id("name")
        email_field = browser.find_element_by_id("email")
        phone_field = browser.find_element_by_id("phone")
        address_field = browser.find_element_by_id("address")
        submit_btn = browser.find_element_by_id("submit")

        uname_field.clear()
        uname_field.send_keys("validUsername")

        pw_field.clear()
        pw_field.send_keys("Password!")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        name_field.clear()
        name_field.send_keys("Name w1th Numb3rs")

        email_field.clear()
        email_field.send_keys("valid.username@email.com.something")

        phone_field.clear()
        phone_field.send_keys("0412987345")

        address_field.clear()
        address_field.send_keys("Somewhere")

        submit_btn.click()
        assert "Name was mistyped. Alphabets only!" in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

        pwConfirm_field = browser.find_element_by_id("confirm")
        name_field = browser.find_element_by_id("name")
        email_field = browser.find_element_by_id("email")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        name_field.clear()
        name_field.send_keys("A Valid Name")

        email_field.clear()
        email_field.send_keys("inval1d.email@@email.com.something")

        submit_btn.click()
        assert "Email contains special characters or was mistyped." in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

        pwConfirm_field = browser.find_element_by_id("confirm")
        email_field = browser.find_element_by_id("email")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        email_field.clear()
        email_field.send_keys("inval1d{email}add@email.com.something")

        submit_btn.click()
        assert "Email contains special characters or was mistyped." in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

        pwConfirm_field = browser.find_element_by_id("confirm")
        email_field = browser.find_element_by_id("email")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        email_field.clear()
        email_field.send_keys("inval1d?Email@email.com.something")

        submit_btn.click()
        assert "Email contains special characters or was mistyped." in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

        pwConfirm_field = browser.find_element_by_id("confirm")
        email_field = browser.find_element_by_id("email")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        email_field.clear()
        email_field.send_keys("inval1d.Email@email.CoM.something")

        submit_btn.click()
        assert "Email domain may contain mistake." in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

        pwConfirm_field = browser.find_element_by_id("confirm")
        email_field = browser.find_element_by_id("email")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        email_field.clear()
        email_field.send_keys("inval1d.Email@email.something")

        submit_btn.click()
        assert "Email domain may contain mistake." in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

        pwConfirm_field = browser.find_element_by_id("confirm")
        email_field = browser.find_element_by_id("email")
        phone_field = browser.find_element_by_id("phone")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        email_field.clear()
        email_field.send_keys("val1d.Email@email.com.something")

        phone_field.clear()
        phone_field.send_keys("0422 123 456")

        submit_btn.click()
        assert "Phone number should contains digits only." in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

        pwConfirm_field = browser.find_element_by_id("confirm")
        phone_field = browser.find_element_by_id("phone")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        phone_field.clear()
        phone_field.send_keys("0422987abc")

        submit_btn.click()
        assert "Phone number should contains digits only." in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

        pwConfirm_field = browser.find_element_by_id("confirm")
        phone_field = browser.find_element_by_id("phone")
        uname_field = browser.find_element_by_id("username")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        phone_field.clear()
        phone_field.send_keys("0419283746")

        uname_field.clear()
        uname_field.send_keys("natsu")

        submit_btn.click()
        assert "Username already taken. Please choose another!" in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

        pwConfirm_field = browser.find_element_by_id("confirm")
        uname_field = browser.find_element_by_id("username")
        submit_btn = browser.find_element_by_id("submit")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Password!")

        uname_field.clear()
        uname_field.send_keys("luvia")

        submit_btn.click()
        assert "Username already taken. Please choose another!" in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/add")
        time.sleep(1.5)

    def test_f_register_success(self):
        uname_field = browser.find_element_by_id("username")
        pw_field = browser.find_element_by_id("password")
        pwConfirm_field = browser.find_element_by_id("confirm")
        name_field = browser.find_element_by_id("name")
        email_field = browser.find_element_by_id("email")
        phone_field = browser.find_element_by_id("phone")
        address_field = browser.find_element_by_id("address")
        submit_btn = browser.find_element_by_id("submit")

        uname_field.clear()
        uname_field.send_keys("erza")

        pw_field.clear()
        pw_field.send_keys("Erzaa!pw")

        pwConfirm_field.clear()
        pwConfirm_field.send_keys("Erzaa!pw")

        name_field.clear()
        name_field.send_keys("Erza Scarlet")

        email_field.clear()
        email_field.send_keys("erza.scarlet@ymail.com")

        phone_field.clear()
        phone_field.send_keys("0419283746")

        address_field.clear()
        address_field.send_keys("Early Fairy Tail")

        submit_btn.click()
        assert "Congrat! You have successfully registered an account. Log-in now!" in browser.page_source
        self.assertEqual(browser.current_url, "http://localhost/CarShareApp/users/login")

    @staticmethod
    def check_existence(title=""):
        try:
            browser.find_element_by_link_text(title)
        except NoSuchElementException:
            return False
        return True

if __name__ == '__main__':
    runTests = RegistrationTest()

    runTests.test_a_signup_button()
    runTests.test_b_password_error_message()
    runTests.test_c_valid_password()
    runTests.test_e_other_inputs()
    runTests.test_f_register_success()
