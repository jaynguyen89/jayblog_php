import unittest
from selenium import webdriver
from random import randint
from selenium.webdriver.common.keys import Keys

browser = webdriver.Chrome("C:/Program Files/chromedriver.exe")
browser.maximize_window()
browser.get("http://localhost/CarShareApp/")

# Test Prerequisite: delete all active rentals belonging
# to Natsu customer before running the tests

class RentalCartTest(unittest.TestCase):
    link1 = ""
    link2 = ""

    def test_a_add_cars(self):
        self.login()

        items = browser.find_element_by_partial_link_text("ITEM")
        self.assertEqual(items.text, "0 ITEM")

        self.navigate()
        addCart_btns = browser.find_elements_by_link_text("ADD TO CART")

        selected_btn = addCart_btns[randint(0, len(addCart_btns) - 1)]
        self.link1 = selected_btn.get_attribute("href")
        selected_btn.click()

        assert "http://localhost/CarShareApp/rentals/edit/" in browser.current_url

    def test_b_shortrental_information(self):
        submit_btn = browser.find_element_by_id("submit")
        self.assertEquals(submit_btn.is_enabled(), False)

        days_field = browser.find_element_by_id("days")
        self.assertEquals(days_field.is_enabled(), False)

        date_field = browser.find_element_by_id("date")

        date_field.send_keys("20092017")
        date_field.send_keys(Keys.TAB)
        date_field.send_keys("0930PM")

        dateEr = browser.find_element_by_id("dateEr")
        self.assertEquals(dateEr.is_displayed(), True)
        self.assertEquals(dateEr.text, "Rental date should be after current date!")
        self.assertEquals(days_field.is_enabled(), False)
        self.assertEquals(submit_btn.is_enabled(), False)

        browser.get(browser.current_url)
        date_field = browser.find_element_by_id("date")
        submit_btn = browser.find_element_by_id("submit")
        days_field = browser.find_element_by_id("days")

        date_field.send_keys("01102017")
        date_field.send_keys(Keys.TAB)
        date_field.send_keys("0930AM")

        dateEr = browser.find_element_by_id("dateEr")
        self.assertEquals(dateEr.is_displayed(), False)
        self.assertEquals(submit_btn.is_enabled(), True)
        self.assertEquals(days_field.is_enabled(), False)

        note_field = browser.find_element_by_id("rentalnote")
        charges_text = browser.find_element_by_id("charges")

        note_field.clear()
        note_field.send_keys("This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters.")
        charges_text.click()

        noteEr = browser.find_element_by_id("count")
        self.assertEquals(noteEr.is_displayed(), True)
        self.assertEquals(noteEr.text, "0 char left!")
        self.assertEquals(days_field.is_enabled(), False)
        self.assertEquals(submit_btn.is_enabled(), False)

        note_field.clear()
        note_field.send_keys("This will not exceed 250 characters. Short rental.")
        charges_text.click()

        self.assertEquals(submit_btn.is_enabled(), True)
        self.assertEquals(days_field.is_enabled(), False)

        submit_btn.click()

        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars")
        assert "The rental has been saved." in browser.page_source

        items = browser.find_element_by_partial_link_text("ITEM")
        self.assertEqual(items.text, "1 ITEM")

    def test_c_longrental_information(self):
        self.add_car(self, 0)

        labels = browser.find_elements_by_tag_name("label")
        labels[1].click()

        submit_btn = browser.find_element_by_id("submit")
        self.assertEquals(submit_btn.is_enabled(), False)

        hours_field = browser.find_element_by_id("hours")
        self.assertEquals(hours_field.is_enabled(), False)

        date_field = browser.find_element_by_id("date")

        date_field.send_keys("20092017")
        date_field.send_keys(Keys.TAB)
        date_field.send_keys("0930PM")

        dateEr = browser.find_element_by_id("dateEr")
        self.assertEquals(dateEr.is_displayed(), True)
        self.assertEquals(dateEr.text, "Rental date should be after current date!")
        self.assertEquals(hours_field.is_enabled(), False)
        self.assertEquals(submit_btn.is_enabled(), False)

        browser.get(browser.current_url)
        date_field = browser.find_element_by_id("date")
        submit_btn = browser.find_element_by_id("submit")
        hours_field = browser.find_element_by_id("hours")

        labels = browser.find_elements_by_tag_name("label")
        labels[1].click()

        date_field.send_keys("02102017")
        date_field.send_keys(Keys.TAB)
        date_field.send_keys("0930AM")

        dateEr = browser.find_element_by_id("dateEr")
        self.assertEquals(dateEr.is_displayed(), False)
        self.assertEquals(submit_btn.is_enabled(), True)
        self.assertEquals(hours_field.is_enabled(), False)

        note_field = browser.find_element_by_id("rentalnote")

        note_field.clear()
        note_field.send_keys("This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters. This will exceed 250 characters.")
        labels[1].click()

        noteEr = browser.find_element_by_id("count")
        self.assertEquals(noteEr.is_displayed(), True)
        self.assertEquals(noteEr.text, "0 char left!")
        self.assertEquals(hours_field.is_enabled(), False)
        self.assertEquals(submit_btn.is_enabled(), False)

        note_field.clear()
        note_field.send_keys("This will not exceed 250 characters. Long rental.")
        labels[1].click()

        self.assertEquals(submit_btn.is_enabled(), True)
        self.assertEquals(hours_field.is_enabled(), False)

        submit_btn.click()

        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars")
        assert "The rental has been saved." in browser.page_source

        #items = browser.find_element_by_partial_link_text("ITEM")
        #self.assertEqual(items.text, "2 ITEM")

    def test_d_clashed_rentals(self):
        self.add_car(self, 1)

        date_field = browser.find_element_by_id("date")

        date_field.send_keys("01102017")
        date_field.send_keys(Keys.TAB)
        date_field.send_keys("0900AM")

        note_field = browser.find_element_by_id("rentalnote")
        note_field.send_keys("Clashed short rental")

        submit_btn = browser.find_element_by_id("submit")
        submit_btn.click()

        assert "Your rental time clashes with both car timetable and your active rental." in browser.page_source

        cancel_btn = browser.find_element_by_link_text("CANCEL RENTAL")
        cancel_btn.click()

        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars")

        self.add_car(self, 2)

        date_field = browser.find_element_by_id("date")

        date_field.send_keys("01102017")
        date_field.send_keys(Keys.TAB)
        date_field.send_keys("0900AM")

        note_field = browser.find_element_by_id("rentalnote")
        note_field.send_keys("Clashed short rental")

        submit_btn = browser.find_element_by_id("submit")
        submit_btn.click()

        assert "Your rental time clashes with your active rental." in browser.page_source

        cancel_btn = browser.find_element_by_link_text("CANCEL RENTAL")
        cancel_btn.click()

        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars")

    @staticmethod
    def login():
        login_btn = browser.find_element_by_link_text("LOG IN")
        login_btn.click()

        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("natsu")

        password_input.clear()
        password_input.send_keys("Natsu!pw")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

    @staticmethod
    def navigate():
        browseCars_tab = browser.find_element_by_link_text("Browse Cars")
        browseCars_tab.click()

    @staticmethod
    def add_car(self, context):
        addCart_btns = browser.find_elements_by_link_text("ADD TO CART")
        if context == 0:
            btn = addCart_btns[randint(0, len(addCart_btns) - 1)]
            self.link2 = btn.get_attribute("href")
            btn.click()
        elif context == 1:
            for btn in addCart_btns:
                if btn.get_attribute("href") == self.link1:
                    btn.click()
                    break
        else:
            selected = False
            while not selected:
                btn = addCart_btns[randint(0, len(addCart_btns) - 1)]

                if btn.get_attribute("href") != self.link1 and btn.get_attribute("href") != self.link2:
                    btn.click()
                    selected = True

if __name__ == '__main__':
    runTests = RentalCartTest()

    runTests.test_a_add_cars()
    runTests.test_b_shortrental_information()
    runTests.test_c_longrental_information()
    runTests.test_d_clashed_rentals()
