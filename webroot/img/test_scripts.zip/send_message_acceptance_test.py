import unittest
from selenium import webdriver
from random import randint
from selenium.webdriver.common.keys import Keys

browser = webdriver.Chrome("C:/Program Files/chromedriver.exe")
browser.maximize_window()
browser.get("http://localhost/CarShareApp/")

# Test `Contact Us` feature for guests, customers
# Test `reply to messages` for admin

class SendMessageTest(unittest.TestCase):
    def test_a_invalid_inputs(self):
        send_btn = browser.find_element_by_id("contactsubmit")
        email_field = browser.find_element_by_id("contactemail")
        name_field = browser.find_element_by_id("contactname")

        email_inputs = ["test", "test!!!", "test@", "test@gmail#com", "test.cu@@gmail.com", "test@gmail."]
        for email in email_inputs:
            email_field.clear()
            email_field.send_keys(email)
            name_field.click()
            assert "Please enter a valid email address." in browser.page_source
            self.assertEquals(send_btn.is_enabled(), False)

        name_inputs = ["test1", "    ", "test!#^", "0123"]
        for name in name_inputs:
            name_field.clear()
            name_field.send_keys(name)
            email_field.click()
            assert "Name should contain alphabet letters only." in browser.page_source
            self.assertEquals(send_btn.is_enabled(), False)

    def test_b_textarea(self):
        message_field = browser.find_element_by_id("contactmessage")
        send_btn = browser.find_element_by_id("contactsubmit")

        self.fill_inputs()
        message_field.clear()
        message_field.send_keys("This would exceed 250 characters. This would exceed 250 characters. This would exceed 250 characters. This would exceed 250 characters. This would exceed 250 characters. This would exceed 250 characters.")
        assert "0 char left!" in browser.page_source
        self.assertEquals(send_btn.is_enabled(), False)

        message_field.clear()
        message_field.send_keys("This will not exceed 250 characters.")
        self.assertEquals(send_btn.is_enabled(), True)

    def test_c_guest_message(self):
        self.fill_inputs()

        send_btn = browser.find_element_by_id("contactsubmit")
        self.assertEquals(send_btn.is_enabled(), True)

        assert "Your message has been sent successfully." in browser.page_source
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/")

    def test_d_customer_message(self):
        self.login()

        email_field = browser.find_element_by_id("contactemail")
        name_field = browser.find_element_by_id("contactname")
        message_field = browser.find_element_by_id("contactmessage")
        send_btn = browser.find_element_by_id("contactsubmit")

        self.assertEquals(email_field.is_enabled(), False)
        email = email_field.get_attribute("value")
        self.assertEquals(email, "natsu.dragneel@gmail.com")

        self.assertEquals(name_field.is_enabled(), False)
        name = name_field.get_attribute("value")
        self.assertEquals(name, "Natsu Dragneel")

        self.assertEquals(send_btn.is_enabled(), False)

        message_field.clear()
        message_field.send_keys("This is a test message for customer.")

        self.assertEquals(send_btn.is_enabled(), True)
        send_btn.click()

        assert "Your message has been sent successfully." in browser.page_source
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/")

    def test_e_customer_inbox(self):
        browser.get("http://localhost/CarShareApp/messages/index")
        reply_btn = browser.find_element_by_link_text("Reply")

        reply_btn.click()
        cancel_btn = reply_btn = browser.find_element_by_link_text("CANCEL")

        cancel_btn.click()
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/messages/index")

        reply_btn.click()
        send_btn = browser.find_element_by_id("repsubmit")
        self.assertEquals(send_btn.is_enabled(), False)

        textbox = browser.find_element_by_id("repmsg")
        textbox.clear()
        textbox.send_keys("This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters.")

        assert "0 char left!" in browser.page_source
        self.assertEquals(send_btn.is_enabled(), False)

        textbox.clear()
        textbox.send_keys("This will not exceed 200 characters.")

        assert "0 char left!" not in browser.page_source
        self.assertEquals(send_btn.is_enabled(), True)
        send_btn.click()

        assert "Your message has been sent successfully." in browser.page_source
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/messages/index")

    def test_f_admin_inbox(self):
        browser.get("http://localhost/CarShareApp/logout")
        login_btn = browser.find_element_by_link_text("LOG IN")
        login_btn.click()

        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("makarov")

        password_input.clear()
        password_input.send_keys("Makarov!pw")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

        browser.get("http://localhost/CarShareApp/messages/index")
        reply_btn = browser.find_element_by_link_text("Reply")

        reply_btn.click()
        cancel_btn = reply_btn = browser.find_element_by_link_text("CANCEL")

        cancel_btn.click()
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/messages/index")

        reply_btn.click()
        send_btn = browser.find_element_by_id("repsubmit")
        self.assertEquals(send_btn.is_enabled(), False)

        textbox = browser.find_element_by_id("repmsg")
        textbox.clear()
        textbox.send_keys(
            "This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters. This will exceed 200 characters.")

        assert "0 char left!" in browser.page_source
        self.assertEquals(send_btn.is_enabled(), False)

        textbox.clear()
        textbox.send_keys("This will not exceed 200 characters.")

        assert "0 char left!" not in browser.page_source
        self.assertEquals(send_btn.is_enabled(), True)
        send_btn.click()

        assert "Your message has been sent successfully." in browser.page_source
        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/messages/index")

    @staticmethod
    def login():
        login_btn = browser.find_element_by_link_text("LOG IN")
        login_btn.click()

        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("natsu")

        password_input.clear()
        password_input.send_keys("Natsu!pw")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

    def fill_inputs(self):
        email_field = browser.find_element_by_id("contactemail")
        name_field = browser.find_element_by_id("contactname")
        message_field = browser.find_element_by_id("contactmessage")

        email_field.clear()
        email_field.send_keys("example.email@email.com")

        name_field.clear()
        name_field.send_keys("Test Name")

        message_field.clear()
        message_field.send_keys("This is a test message.")

if __name__ == '__main__':
    runTests = SendMessageTest()

    runTests.test_a_invalid_inputs()
    runTests.test_b_textarea()
    runTests.test_c_guest_message()
    runTests.test_d_customer_message()
    runTests.test_e_customer_inbox()
    runTests.test_f_admin_inbox()
