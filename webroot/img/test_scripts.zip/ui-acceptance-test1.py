import unittest
from selenium import webdriver
from random import randint
from selenium.common.exceptions import NoSuchElementException

browser = webdriver.Chrome("C:/Program Files/chromedriver.exe")
browser.maximize_window()
browser.get("http://localhost/CarShareApp/")


class UITest(unittest.TestCase):
    def test_a_before_login(self):
        login_btn_lookup = self.check_existence("LOG IN")
        logout_btn_lookup = self.check_existence("LOGOUT")
        signup_btn_lookup = self.check_existence("SIGN UP")

        self.assertEquals(login_btn_lookup, True)
        self.assertEquals(logout_btn_lookup, False)
        self.assertEquals(signup_btn_lookup, True)

        if login_btn_lookup:
            login_btn = browser.find_element_by_link_text("LOG IN")
            login_btn.click()

            login_btn_lookup = self.check_existence("LOG IN")
            logout_btn_lookup = self.check_existence("LOGOUT")
            signup_btn_lookup = self.check_existence("SIGN UP")

            self.assertEquals(login_btn_lookup, False)
            self.assertEquals(logout_btn_lookup, False)
            self.assertEquals(signup_btn_lookup, True)

            if signup_btn_lookup:
                signup_btn = browser.find_element_by_link_text("SIGN UP")
                signup_btn.click()

                login_btn_lookup = self.check_existence("LOG IN")
                logout_btn_lookup = self.check_existence("LOGOUT")
                signup_btn_lookup = self.check_existence("SIGN UP")

                self.assertEquals(login_btn_lookup, True)
                self.assertEquals(logout_btn_lookup, False)
                self.assertEquals(signup_btn_lookup, False)

    def test_b_customer_home(self):
        self.login()
        assert "http://localhost/CarShareApp/customers/dashboard/" in browser.current_url

        logout_btn_lookup = self.check_existence("LOGOUT")
        self.assertEquals(logout_btn_lookup, True)

        cart_btn_lookup = self.check_existence("ITEM", 1)
        self.assertEquals(cart_btn_lookup, True)

        browse_link_lookup = self.check_existence("Browse Cars")
        self.assertEquals(browse_link_lookup, True)

        map_link_lookup = self.check_existence("Cars Map")
        self.assertEquals(map_link_lookup, True)

        pricing_link_lookup = self.check_existence("Pricing")
        self.assertEquals(pricing_link_lookup, True)

        return_link_lookup = self.check_existence("Return Car")
        self.assertEquals(return_link_lookup, True)

        home_link_lookup = self.check_existence("Welcome!", 1)
        self.assertEquals(home_link_lookup, True)

        update_btn_lookup = self.check_existence("UPDATE PROFILE")
        self.assertEquals(update_btn_lookup, True)

        account_tab_lookup = self.check_existence("Account Information")
        self.assertEquals(account_tab_lookup, True)

        history_tab_lookup = self.check_existence("Rental History")
        self.assertEquals(history_tab_lookup, True)

        watched_tab_lookup = self.check_existence("Watched Cars")
        self.assertEquals(watched_tab_lookup, True)

        recent_tab_lookup = self.check_existence("Recent Browsing")
        self.assertEquals(recent_tab_lookup, True)

    def test_c_browsing_page(self):
        browse_link = browser.find_element_by_link_text("Browse Cars")
        browse_link.click()

        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars")

        logout_btn_lookup = self.check_existence("LOGOUT")
        self.assertEquals(logout_btn_lookup, True)

        cart_btn_lookup = self.check_existence("ITEM", 1)
        self.assertEquals(cart_btn_lookup, True)

        browse_link_lookup = self.check_existence("Browse Cars")
        self.assertEquals(browse_link_lookup, True)

        map_link_lookup = self.check_existence("Cars Map")
        self.assertEquals(map_link_lookup, True)

        pricing_link_lookup = self.check_existence("Pricing")
        self.assertEquals(pricing_link_lookup, True)

        return_link_lookup = self.check_existence("Return Car")
        self.assertEquals(return_link_lookup, True)

        home_link_lookup = self.check_existence("Welcome!", 1)
        self.assertEquals(home_link_lookup, True)

        refine_btn_lookup = self.check_existence("APPLY")
        self.assertEquals(refine_btn_lookup, True)

        view_btn_lookup = self.check_existence("View")
        self.assertEquals(view_btn_lookup, True)

        add_btn_lookup = self.check_existence("ADD TO CART")
        self.assertEquals(add_btn_lookup, True)

    def test_d_view_car_page(self):
        view_btns = browser.find_elements_by_link_text("VIEW")
        view_btns[randint(0, len(view_btns) - 1)].click()

        assert "http://localhost/CarShareApp/cars/view/" in browser.current_url

        logout_btn_lookup = self.check_existence("LOGOUT")
        self.assertEquals(logout_btn_lookup, True)

        cart_btn_lookup = self.check_existence("ITEM", 1)
        self.assertEquals(cart_btn_lookup, True)

        browse_link_lookup = self.check_existence("Browse Cars")
        self.assertEquals(browse_link_lookup, True)

        map_link_lookup = self.check_existence("Cars Map")
        self.assertEquals(map_link_lookup, True)

        pricing_link_lookup = self.check_existence("Pricing")
        self.assertEquals(pricing_link_lookup, True)

        return_link_lookup = self.check_existence("Return Car")
        self.assertEquals(return_link_lookup, True)

        home_link_lookup = self.check_existence("Welcome!", 1)
        self.assertEquals(home_link_lookup, True)

        add_btn_lookup = self.check_existence("ADD TO CART")
        self.assertEquals(add_btn_lookup, True)

        watch_btn_lookup = self.check_existence("WATCH")
        self.assertEquals(watch_btn_lookup, True)

        distance_btn_lookup = self.check_existence("SHOW DISTANCE")
        self.assertEquals(distance_btn_lookup, False)

    def test_e_map_page(self):
        map_link = browser.find_element_by_link_text("Cars Map")
        map_link.click()

        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/cars/cars-on-map")

        logout_btn_lookup = self.check_existence("LOGOUT")
        self.assertEquals(logout_btn_lookup, True)

        cart_btn_lookup = self.check_existence("ITEM", 1)
        self.assertEquals(cart_btn_lookup, True)

        browse_link_lookup = self.check_existence("Browse Cars")
        self.assertEquals(browse_link_lookup, True)

        map_link_lookup = self.check_existence("Cars Map")
        self.assertEquals(map_link_lookup, True)

        pricing_link_lookup = self.check_existence("Pricing")
        self.assertEquals(pricing_link_lookup, True)

        return_link_lookup = self.check_existence("Return Car")
        self.assertEquals(return_link_lookup, True)

        home_link_lookup = self.check_existence("Welcome!", 1)
        self.assertEquals(home_link_lookup, True)

    def test_f_pricing_page(self):
        pricing_link = browser.find_element_by_link_text("Pricing")
        pricing_link.click()

        self.assertEquals(browser.current_url, "http://localhost/CarShareApp/pages/pricing")

        logout_btn_lookup = self.check_existence("LOGOUT")
        self.assertEquals(logout_btn_lookup, True)

        cart_btn_lookup = self.check_existence("ITEM", 1)
        self.assertEquals(cart_btn_lookup, True)

        browse_link_lookup = self.check_existence("Browse Cars")
        self.assertEquals(browse_link_lookup, True)

        map_link_lookup = self.check_existence("Cars Map")
        self.assertEquals(map_link_lookup, True)

        pricing_link_lookup = self.check_existence("Pricing")
        self.assertEquals(pricing_link_lookup, True)

        return_link_lookup = self.check_existence("Return Car")
        self.assertEquals(return_link_lookup, True)

        home_link_lookup = self.check_existence("Welcome!", 1)
        self.assertEquals(home_link_lookup, True)

        short_pricing_tab = self.check_existence("Short Rentals Pricing", 1)
        long_pricing_tab = self.check_existence("Long Rentals Pricing", 1)
        policies_tab = self.check_existence("Return Policies", 1)
        tnc_tab = self.check_existence("Terms & Conditions", 1)

        self.assertEquals(short_pricing_tab, True)
        self.assertEquals(long_pricing_tab, True)
        self.assertEquals(policies_tab, True)
        self.assertEquals(tnc_tab, True)

    def test_g_rental_page(self):
        browse_link = browser.find_element_by_link_text("Browse Cars")
        browse_link.click()

        addCart_btns = browser.find_elements_by_link_text("ADD TO CART")
        addCart_btns[randint(0, len(addCart_btns) - 1)].click()

        logout_btn_lookup = self.check_existence("LOGOUT")
        self.assertEquals(logout_btn_lookup, True)

        cart_btn_lookup = self.check_existence("ITEM", 1)
        self.assertEquals(cart_btn_lookup, True)

        browse_link_lookup = self.check_existence("Browse Cars")
        self.assertEquals(browse_link_lookup, True)

        map_link_lookup = self.check_existence("Cars Map")
        self.assertEquals(map_link_lookup, True)

        pricing_link_lookup = self.check_existence("Pricing")
        self.assertEquals(pricing_link_lookup, True)

        return_link_lookup = self.check_existence("Return Car")
        self.assertEquals(return_link_lookup, True)

        home_link_lookup = self.check_existence("Welcome!", 1)
        self.assertEquals(home_link_lookup, True)

        submit_btn_lookup = self.check_existence("submit", 2)
        self.assertEquals(submit_btn_lookup, True)

        cancel_btn_lookup = self.check_existence("CANCEL RENTAL")
        self.assertEquals(cancel_btn_lookup, True)

        continue_link_lookup = self.check_existence("Continue Browsing")
        self.assertEquals(continue_link_lookup, True)

        if cancel_btn_lookup:
            cancel_btn = browser.find_element_by_link_text("CANCEL RENTAL")
            cancel_btn.click()

            if logout_btn_lookup:
                logout_btn = browser.find_element_by_link_text("LOGOUT")
                logout_btn.click()

    @staticmethod
    def login():
        login_btn = browser.find_element_by_link_text("LOG IN")
        login_btn.click()

        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("natsu")

        password_input.clear()
        password_input.send_keys("Natsu!pw")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

    @staticmethod
    def check_existence(title, context=0):
        try:
            if context == 0:
                browser.find_element_by_link_text(title)
            elif context == 1:
                browser.find_element_by_partial_link_text(title)
            else:
                browser.find_element_by_id(title)
        except NoSuchElementException:
            return False
        return True

if __name__ == '__main__':
    runTests = UITest()

    runTests.test_a_before_login()
    runTests.test_b_customer_home()
    runTests.test_c_browsing_page()
    runTests.test_d_view_car_page()
    runTests.test_e_map_page()
    runTests.test_f_pricing_page()
    runTests.test_g_rental_page()
