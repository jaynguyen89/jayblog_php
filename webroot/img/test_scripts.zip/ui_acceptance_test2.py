import unittest
from selenium import webdriver
from random import randint
from selenium.webdriver.common.keys import Keys

browser = webdriver.Chrome("C:/Program Files/chromedriver.exe")
browser.maximize_window()
browser.get("http://localhost/CarShareApp/")

# Test the responses of elements in `Add Car` fields
# Ensure the elements show, hide, enabled, disabled correctly


class AddCarTest(unittest.TestCase):
    link = ""

    # Test that correct error messages displayed for incorrect make and model input events
    def test_a_addcar_step1_test1(self):
        self.login()
        self.go_next(self, 0, "")

        next_btn = browser.find_element_by_id("nextstep")
        self.assertEquals(next_btn.is_enabled(), False)

        make_drop = browser.find_element_by_id("make")
        make_checkbox = browser.find_element_by_id("selectmake")
        make_field = browser.find_element_by_id("maketext")

        self.assertEquals(make_checkbox.is_selected(), False)
        self.assertEquals(make_field.is_enabled(), False)
        self.assertEquals(make_drop.is_enabled(), True)

        make_checkbox.click()
        self.assertEquals(make_drop.is_enabled(), False)
        self.assertEquals(make_field.is_enabled(), True)

        model_checkbox = browser.find_element_by_id("selectmodel")
        model_drop = browser.find_element_by_id("model")
        model_field = browser.find_element_by_id("modeltext")

        self.assertEquals(model_checkbox.is_selected(), True)
        self.assertEquals(model_drop.is_enabled(), False)
        self.assertEquals(model_field.is_enabled(), True)

        make_field.clear()
        make_field.send_keys("Toyota")
        assert "This brand is available in dropdown. Please use dropdown instead." in browser.page_source
        self.assertEquals(next_btn.is_enabled(), False)

        make_field.clear()
        make_field.send_keys("Mercedes")
        assert "This brand is available in dropdown. Please use dropdown instead." not in browser.page_source

        make_drop.click()
        make_drop.send_keys("Toyota")

        model_field.clear()
        model_field.send_keys("86 Edition")

        assert "This car has been added already. You can edit it instead." in browser.page_source
        self.assertEquals(next_btn.is_enabled(), False)

    # Test that the first model corresponding to the selected make is set as default when switching make in dropdown
    # Test that the make corresponding to the selected model is set when switching model in dropdown
    def test_b_addcar_step1_test2(self):
        browser.get(browser.current_url)

        make_drop = browser.find_element_by_id("make")
        model_drop = browser.find_element_by_id("model")

        make_options = make_drop.find_elements_by_tag_name("options")
        model_optgroups = model_drop.find_elements_by_tag_name("optgroup")

        model_options = {}
        for optgroup in model_optgroups:
            options = optgroup.find_elements_by_tag_name("option")
            model_options[optgroup.text] = options

        selected_make = "Aston Martin"
        make_drop.send_keys(selected_make)

        model = model_drop.get_attribute("value")
        self.assertEquals(model, model_options[selected_make][0])

        selected_model = "518Li"
        model_drop.send_keys(selected_model)

        make = make_drop.get_attribute("value")
        assert make in make_options

    def test_c_addcar_step1_test3(self):
        nextbtn = browser.find_element_by_id("nextstep")
        year_field = browser.find_element_by_id("year")

        year_inputs = [-1, -21, 2019, 2020, 1970, 1960]
        for input in year_inputs:
            year_field.send_keys(input)
            assert "Year is invalid or nonsense. Please check again." or \
                   "Year is valid. But you really want to add this car to the business?" in browser.page_source
            self.assertEquals(nextbtn.is_enabled(), False)

        conv_checkbox = browser.find_element_by_id("selectconv")
        conv_field = browser.find_element_by_id("convtext")
        conv_drop = browser.find_element_by_id("convenience")

        conv_checkbox.click()
        self.assertEquals(conv_field.is_enabled(), True)
        self.assertEquals(conv_drop.is_enabled(), False)
        self.assertEquals(nextbtn.is_enabled(), False)

        conv_field.send_keys("Convertible")
        nextbtn.click()
        assert "This body type is available in dropdown. Please use dropdown instead." in browser.page_source
        self.assertEquals(nextbtn.is_enabled(), False)

        nextbtn.click()
        assert "This body type is available in dropdown. Please use dropdown instead." not in browser.page_source

        seat_field = browser.find_element_by_id("seats")

        seat_inputs = [-10, 0, 100, 111]
        for input in seat_inputs:
            seat_field.send_keys(input)
            assert "The number of seats is invalid. Please check again." or \
                   "The number of seats are valid. But please double check if it is correct." in browser.page_source
            self.assertEquals(nextbtn.is_enabled(), False)

        fuel_drop = browser.find_element_by_id("fueltype")
        fuel_checkbox = browser.find_element_by_id("selectfuel")
        fuel_field = browser.find_element_by_id("fueltext")

        fuel_checkbox.click()
        self.assertEquals(fuel_drop.is_enabled(), False)
        self.assertEquals(fuel_field.is_enabled(), True)
        self.assertEquals(nextbtn.is_enabled(), False)

        fuel_field.send_keys("autogas")
        nextbtn.click()
        assert "This fuel type is available in dropdown. Please use dropdown instead." in browser.page_source

        fuel_checkbox.click()
        assert "This fuel type is available in dropdown. Please use dropdown instead." not in browser.page_source
        self.assertEquals(nextbtn.is_enabled(), False)

        odo_field = browser.find_element_by_id("odometer")
        odo_field.send_keys(-10)

        assert "Invalid number input. Please check again." in browser.page_source
        self.assertEquals(nextbtn.is_enabled(), False)

        odo_field.send_keys(0)
        assert "Invalid number input. Please check again." not in browser.page_source
        self.assertEquals(nextbtn.is_enabled(), False)

        length_field = browser.find_element_by_id("length")
        width_field = browser.find_element_by_id("width")
        height_field = browser.find_element_by_id("height")

        fields = [length_field, width_field, height_field]

        inputs = [-10293, 00000, -10, 123, 32432423, 0, 3123, -2423, -3423, -11]
        for i in range(0, 10):
            for field in fields:
                input = inputs[randint(0, len(inputs) - 1)]
                field.send_keys(input)

            assert "Dimension values are invalid. Please check again." or \
                   "Dimension values are valid. But please double check before next step!" in browser.page_source

    def test_d_addcar_step2_test1(self):
        self.go_next(self, 1, browser.current_url)
        browser.get(self.link)

        entype_checkbox = browser.find_element_by_id("selectenginetype")
        entype_field = browser.find_element_by_id("enginetypetext")
        entype_drop = browser.find_element_by_id("enginetype")

        entype_checkbox.click()
        self.assertEquals(entype_drop.is_enabled(), False)
        self.assertEquals(entype_field.is_enabled(), True)

        entype_field.send_keys("straight")
        assert "Engine type found in dropdown. Please use dropdown instead." in browser.page_source

        entype_checkbox.click()
        assert "Engine type found in dropdown. Please use dropdown instead." not in browser.page_source

        induct_drop = browser.find_element_by_id("induction")
        induct_checkbox = browser.find_element_by_id("selectinduct")
        induct_field = browser.find_element_by_id("inducttext")

        induct_checkbox.click()
        self.assertEquals(induct_drop.is_enabled(), False)
        self.assertEquals(induct_field.is_enabled(), True)

        induct_field.send_keys("Centrifugal Supercharger")
        assert "Induction record found in dropdown. Please use dropdown instead." in browser.page_source

        induct_checkbox.click()
        assert "Induction record found in dropdown. Please use dropdown instead." not in browser.page_source

        size_inputs = [-2121, 432432, -1, 9999, 1]

        enzise_field = browser.find_element_by_id("enginesize")
        for input in size_inputs:
            enzise_field.send_keys(input)
            assert "Engine size is invalid. Please check again." or \
                   "Engine size is valid. But please check again before next step." in browser.page_source

        enzise_field.send_keys(0)
        assert "Engine size is invalid. Please check again." or \
                   "Engine size is valid. But please check again before next step." not in browser.page_source

        cylinder_inputs = [-132, -1, 11, 212]

        cylinder_field = browser.find_element_by_id("cylinder")
        for input in cylinder_inputs:
            cylinder_field.send_keys(input)
            assert "Cylinder is invalid. Please check again." or \
                   "Cylinder is valid. But please check again before next step." in browser.page_source

        cylinder_field.send_keys(0)
        assert "Cylinder is invalid. Please check again." or \
               "Cylinder is valid. But please check again before next step." not in browser.page_source

    def test_e_addcar_step2_test2(self):
        watt_field = browser.find_element_by_id("watt")
        round_field = browser.find_element_by_id("round")

        fields = [watt_field, round_field]
        inputs = [-12, -23, 5000, -13, -1]
        for i in range(0, 10):
            input = inputs[randint(0, len(inputs) - 1)]
            for field in fields:
                field.send_keys(input)

            assert "Either or both of Watt or/and RPM value is invalid. Please check again." in browser.page_source

        for field in fields:
            field.send_keys(0)

        assert "Either or both of Watt or/and RPM value is invalid. Please check again." not in browser.page_source

        for field in fields:
            field.send_keys(100)

        assert "Either or both of Watt or/and RPM value is invalid. Please check again." not in browser.page_source

        gear_inputs = [-1, -10, -100, 100, 1234]
        gear_field = browser.find_element_by_id("gear")

        for input in gear_inputs:
            gear_field.send_keys(input)
            assert "Gear is invalid. Please check again." or \
                   "Gear is valid. But please check again before next step." in browser.page_source

        gear_field.send_keys(0)
        assert "Gear is invalid. Please check again." or \
                   "Gear is valid. But please check again before next step." in browser.page_source

        geartype = browser.find_element_by_id("geartype")
        geartext = browser.find_element_by_id("geartext")
        gearcheck = browser.find_element_by_id("selectgear")

        gearcheck.click()
        self.assertEquals(geartype.is_enabled(), False)
        self.assertEquals(geartext.is_enabled(), True)

        geartext.send_keys("engine")
        assert "Gear type found in dropdown. Please use dropdown instead." in browser.page_source

        gearcheck.click()
        assert "Gear type found in dropdown. Please use dropdown instead." not in browser.page_source

        fuel_field = browser.find_element_by_id("fuelcap")
        fuel_field.send_keys(-1)
        assert "Fuel capacity is invalid. Please check again." in browser.page_source
        fuel_field.send_keys(0)
        assert "Fuel capacity is invalid. Please check again." not in browser.page_source

        ave_field = browser.find_element_by_id("average")
        ru_field = browser.find_element_by_id("rural")
        ur_field = browser.find_element_by_id("urbane")

        ffields = [ave_field, ru_field, ur_field]
        consumes = [0, -1.1, -10.2, -20, -30, -40, 10.5]

        for i in range(0, 10):
            input = consumes[randint(0, len(consumes) - 1)]
            for field in ffields:
                field.send_keys(input)

            assert "Either of consumption values is invalid. Please check again." in browser.page_source

    def test_f_addcar_step3(self):
        self.go_next(self, 1, browser.current_url)
        browser.get(self.link)

        conv_checkbox = browser.find_element_by_id("selectconv")
        conv_field = browser.find_element_by_id("convtext")
        conv_text = browser.find_element_by_id("convenience")

        conv_checkbox.click()
        self.assertEquals(conv_field.is_enabled(), True)
        self.assertEquals(conv_text.is_enabled(), True)

        trconv = browser.find_element_by_id("trconv")
        suggestions = trconv.find_elements_by_tag_name("a")

        suggest_texts = []
        for el in suggestions:
            suggest_texts.append(el.text)

        for i in range(0, len(suggestions) - 1):
            suggestions[i].click()
            clicked_text = suggest_texts[i]

            convtext = browser.find_element_by_id("convenience").get_attribute("value")
            assert clicked_text in convtext

        for i in range(0, 10):
            conv_field.send_keys("Test" + i)

            convtext = browser.find_element_by_id("convenience").get_attribute("value")
            assert "Test" + i in convtext

    def test_g_addcar_step4(self):
        self.go_next(self, 1, browser.current_url)
        browser.get(self.link)

        next_btn = browser.find_element_by_id("nextstep")
        self.assertEquals(next_btn.is_enabled(), False)

        short_field = browser.find_element_by_id("shortdesc")
        input = ""
        for i in range(0, 100):
            input += i + " "
            short_field.send_keys(input)

            assert str(250 - i*2) + "characters left" in browser.page_source
            self.assertEquals(next_btn.is_enabled(), True)

        long_field = browser.find_element_by_id("description")
        input = ""
        for i in range(0, 100):
            input += i + " "
            long_field.send_keys(input)

            assert str(1500 - i * 2) + "characters left" in browser.page_source
            self.assertEquals(next_btn.is_enabled(), True)

        long_field.send_keys("")
        self.assertEquals(next_btn.is_enabled(), True)

        short_field.send_keys("")
        self.assertEquals(next_btn.is_enabled(), False)

    def test_h_addcar_step5(self):
        self.go_next(self, 1, browser.current_url)
        browser.get(self.link)

        publish_btn = browser.find_element_by_id("publish")

        dprice_field = browser.find_element_by_id("ddprice")
        kprice_field = browser.find_element_by_id("kmprice")

        fields = [dprice_field, kprice_field]
        inputs = [-1, -10, -1.1, -10.2, -1000, -500.500]

        for i in range(0, 10):
            input = inputs[randint(0, len(inputs) - 1)]
            for field in fields:
                field.send_keys(input)

                assert "Invalid price. Price can not be negative." in browser.page_source
                self.assertEquals(publish_btn.is_enabled(), False)

        park_field = browser.find_element_by_id("parking")
        park_field.send_keys("uh133g78")

        assert "Unable to locate the Parking Address. Please check again." in browser.page_source
        self.assertEquals(publish_btn.is_enabled(), False)

    @staticmethod
    def login():
        login_btn = browser.find_element_by_link_text("LOG IN")
        login_btn.click()

        username_input = browser.find_element_by_id("username")
        password_input = browser.find_element_by_id("password")

        username_input.clear()
        username_input.send_keys("makarov")

        password_input.clear()
        password_input.send_keys("Makarov!pw")

        section = browser.find_element_by_tag_name("form")
        submit_btn = section.find_element_by_tag_name("button")
        submit_btn.click()

    @staticmethod
    def go_next(self, context, link=""):
        if context == 0:
            add_tab = browser.find_element_by_link_text("Add")
            add_tab.click()

        if context == 1:
            tokens = link.split("\\")
            tokens[len(tokens) - 2] = (
                "add-second" if tokens[len(tokens) - 2] == "add-first" else (
                    "add-third" if tokens[len(tokens) - 2] == "add-second" else (
                        "add-fourth" if tokens[len(tokens) - 2] == "add-third" else (
                            "add-last" if tokens[len(tokens) - 2] == "add-fourth" else ""
                        )
                    )
                ))
            self.link = "\\".join([str(s) for s in tokens])

if __name__ == '__main__':
    runTests = AddCarTest()

    runTests.test_a_addcar_step1_test1()
    runTests.test_b_addcar_step1_test2()
    runTests.test_c_addcar_step1_test3()
    runTests.test_d_addcar_step2_test1()
    runTests.test_e_addcar_step2_test2()
    runTests.test_f_addcar_step3()
    runTests.test_g_addcar_step4()
    runTests.test_h_addcar_step5()